'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import {
  Camera,
  CameraOff,
  Check,
  ChevronsLeftRight,
  ImagePlus,
  Loader2,
  RotateCcw,
  Upload,
  Video,
  Circle,
  X,
} from 'lucide-react'

type CameraCategory = {
  id: string
  name: string
  slug: string
}

type CameraStudioProps = {
  returnTo: string
  categories: CameraCategory[]
}

type CaptureMode = 'photo' | 'video'
type PublishTarget = 'post' | 'story'
type InputSource = 'camera' | 'upload'

const ACCEPTED_IMAGE_TYPES = new Set([
  'image/jpeg',
  'image/png',
  'image/webp',
])

const ACCEPTED_VIDEO_TYPES = new Set([
  'video/webm',
  'video/mp4',
  'video/quicktime',
])

export function CameraStudio({
  returnTo,
  categories,
}: CameraStudioProps) {
  const router = useRouter()

  const videoRef = useRef<HTMLVideoElement | null>(null)
  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const recorderRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])

  const [mode, setMode] = useState<CaptureMode>('photo')
  const [target, setTarget] = useState<PublishTarget>('post')
  const [source, setSource] = useState<InputSource>('camera')
  const [caption, setCaption] = useState('')
  const [categoryId, setCategoryId] = useState('')
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment')
  const [cameraReady, setCameraReady] = useState(false)
  const [cameraError, setCameraError] = useState('')
  const [recording, setRecording] = useState(false)
  const [publishing, setPublishing] = useState(false)
  const [cameraSupported, setCameraSupported] = useState(true)

  const [capturedFile, setCapturedFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState('')

  const resolvedMediaType = useMemo(
    () => (mode === 'photo' ? 'image' : 'video'),
    [mode]
  )

  useEffect(() => {
    const hasCameraApi =
      typeof navigator !== 'undefined' &&
      !!navigator.mediaDevices &&
      typeof navigator.mediaDevices.getUserMedia === 'function'

    setCameraSupported(hasCameraApi)

    if (!hasCameraApi) {
      setCameraError('This browser/device does not support in-app camera access. Use upload instead.')
      setSource('upload')
      return
    }

    if (source === 'camera') {
      void startCamera()
    }

    return () => {
      stopCamera()
    }
  }, [facingMode, source, mode])

  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl)
    }
  }, [previewUrl])

  function revokePreview() {
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl)
    }
  }

  function stopCamera() {
    recorderRef.current = null

    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }

    setCameraReady(false)
    setRecording(false)
  }

  async function startCamera() {
    try {
      stopCamera()
      setCameraError('')

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: mode === 'video',
        video: {
          facingMode,
          width: { ideal: 1080 },
          height: { ideal: 1920 },
        },
      })

      streamRef.current = stream

      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()
      }

      setCameraReady(true)
    } catch (error: any) {
      setCameraReady(false)
      setCameraError(
        error?.message || 'Unable to access camera on this device/browser.'
      )
    }
  }

  function clearCapture() {
    revokePreview()
    setCapturedFile(null)
    setPreviewUrl('')
    setPublishing(false)
  }

  async function handleTakePhoto() {
    const video = videoRef.current
    if (!video) return

    const canvas = document.createElement('canvas')
    canvas.width = video.videoWidth || 1080
    canvas.height = video.videoHeight || 1920

    const context = canvas.getContext('2d')
    if (!context) return

    context.drawImage(video, 0, 0, canvas.width, canvas.height)

    const blob = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob(resolve, 'image/jpeg', 0.92)
    )

    if (!blob) return

    const file = new File([blob], `camera-photo-${Date.now()}.jpg`, {
      type: 'image/jpeg',
    })

    revokePreview()
    setCapturedFile(file)
    setPreviewUrl(URL.createObjectURL(file))
  }

  function startVideoRecording() {
    const stream = streamRef.current
    if (!stream) return

    const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
      ? 'video/webm;codecs=vp9'
      : 'video/webm'

    const recorder = new MediaRecorder(stream, { mimeType })
    chunksRef.current = []

    recorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        chunksRef.current.push(event.data)
      }
    }

    recorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: 'video/webm' })
      const file = new File([blob], `camera-video-${Date.now()}.webm`, {
        type: 'video/webm',
      })

      revokePreview()
      setCapturedFile(file)
      setPreviewUrl(URL.createObjectURL(file))
      setRecording(false)
    }

    recorderRef.current = recorder
    recorder.start()
    setRecording(true)
  }

  function stopVideoRecording() {
    recorderRef.current?.stop()
  }

  function isAcceptedUpload(file: File) {
    if (mode === 'photo') {
      return ACCEPTED_IMAGE_TYPES.has(file.type)
    }

    return ACCEPTED_VIDEO_TYPES.has(file.type)
  }

  function handleUploadSelect(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    if (!file) return

    if (!isAcceptedUpload(file)) {
      setCameraError(
        mode === 'photo'
          ? 'Use JPG, PNG, or WEBP for photo upload.'
          : 'Use WEBM, MP4, or MOV for video upload.'
      )
      event.target.value = ''
      return
    }

    setCameraError('')
    revokePreview()
    setCapturedFile(file)
    setPreviewUrl(URL.createObjectURL(file))
  }

  async function handlePublish() {
    if (!capturedFile) return

    try {
      setPublishing(true)
      setCameraError('')

      const formData = new FormData()
      formData.set('target', target)
      formData.set('media_type', resolvedMediaType)
      formData.set('caption', caption.trim())
      formData.set('category_id', target === 'post' ? categoryId : '')
      formData.set('return_to', returnTo)
      formData.set('media_file', capturedFile)

      const response = await fetch('/api/camera/publish', {
        method: 'POST',
        body: formData,
      })

      const payload = await response.json()

      if (!response.ok || !payload?.ok) {
        throw new Error(payload?.error || 'camera_publish_failed')
      }

      router.push(payload.redirectUrl || returnTo)
      router.refresh()
    } catch (error: any) {
      setPublishing(false)
      setCameraError(error?.message || 'Failed to publish captured media.')
    }
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <div className="mx-auto flex min-h-screen max-w-6xl flex-col gap-5 px-4 py-4 md:px-6 md:py-6">
        <div className="flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => router.push(returnTo || '/feed')}
            className="rounded-2xl border border-zinc-800 bg-zinc-950/90 px-4 py-3 text-sm font-medium text-zinc-300 transition hover:border-zinc-700 hover:text-white"
          >
            Back
          </button>

          <div className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.16em] text-zinc-300">
            Camera studio
          </div>
        </div>

        {cameraError ? (
          <div className="rounded-2xl border border-red-900/40 bg-red-950/25 px-4 py-3 text-sm text-red-100">
            {cameraError}
          </div>
        ) : null}

        <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_360px]">
          <section className="overflow-hidden rounded-[26px] md:rounded-[30px] border border-zinc-800/90 bg-[linear-gradient(180deg,rgba(18,18,24,0.98),rgba(8,8,10,0.98))] shadow-[0_14px_32px_rgba(0,0,0,0.20)]">
            <div className="relative aspect-[9/16] bg-black">
              {!previewUrl && source === 'camera' ? (
                <>
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="h-full w-full object-cover"
                  />

                  {!cameraReady ? (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/70 text-zinc-400">
                      <Loader2 className="h-6 w-6 animate-spin" />
                    </div>
                  ) : null}
                </>
              ) : previewUrl ? (
                resolvedMediaType === 'image' ? (
                  <img
                    src={previewUrl}
                    alt="Captured preview"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <video
                    src={previewUrl}
                    controls
                    playsInline
                    className="h-full w-full object-cover"
                  />
                )
              ) : (
                <div className="flex h-full w-full flex-col items-center justify-center gap-4 bg-zinc-950 px-6 text-center">
                  <div className="inline-flex h-16 w-16 items-center justify-center rounded-full border border-zinc-800 bg-black text-zinc-400">
                    {cameraSupported ? (
                      <Upload className="h-7 w-7" />
                    ) : (
                      <CameraOff className="h-7 w-7" />
                    )}
                  </div>
                  <div>
                    <p className="text-lg font-semibold text-white">
                      {cameraSupported ? 'Upload media instead' : 'Camera unavailable'}
                    </p>
                    <p className="mt-2 text-sm leading-7 text-zinc-400">
                      {cameraSupported
                        ? 'Choose a photo or video directly from your device.'
                        : 'This browser or device cannot access the in-app camera. Upload media instead.'}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="rounded-2xl border border-white bg-[linear-gradient(90deg,#ffffff_0%,#f3f3ff_100%)] px-5 py-3 text-sm font-semibold text-black transition hover:opacity-90"
                  >
                    Choose file
                  </button>
                </div>
              )}

              <input
                ref={fileInputRef}
                type="file"
                accept={mode === 'photo' ? 'image/jpeg,image/png,image/webp' : 'video/webm,video/mp4,video/quicktime'}
                className="hidden"
                onChange={handleUploadSelect}
              />

              {!previewUrl ? (
                <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-3 bg-gradient-to-t from-black/90 via-black/20 to-transparent px-4 pb-4 pt-20">
                  <button
                    type="button"
                    onClick={() => {
                      if (source === 'camera') {
                        setFacingMode((current) =>
                          current === 'user' ? 'environment' : 'user'
                        )
                      } else {
                        fileInputRef.current?.click()
                      }
                    }}
                    className="inline-flex h-12 w-12 items-center justify-center rounded-full border border-white/10 bg-black/60 text-white transition hover:bg-black/75"
                  >
                    {source === 'camera' ? (
                      <ChevronsLeftRight className="h-5 w-5" />
                    ) : (
                      <ImagePlus className="h-5 w-5" />
                    )}
                  </button>

                  {source === 'camera' ? (
                    mode === 'photo' ? (
                      <button
                        type="button"
                        onClick={handleTakePhoto}
                        disabled={!cameraReady}
                        className="inline-flex h-16 w-16 items-center justify-center rounded-full border-4 border-white bg-white/10 text-white transition hover:scale-[1.02] disabled:opacity-60"
                      >
                        <Camera className="h-7 w-7" />
                      </button>
                    ) : !recording ? (
                      <button
                        type="button"
                        onClick={startVideoRecording}
                        disabled={!cameraReady}
                        className="inline-flex h-16 w-16 items-center justify-center rounded-full border-4 border-red-500 bg-red-500/20 text-red-300 transition hover:scale-[1.02] disabled:opacity-60"
                      >
                        <Circle className="h-7 w-7 fill-current" />
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={stopVideoRecording}
                        className="inline-flex h-16 w-16 items-center justify-center rounded-full border-4 border-red-500 bg-red-500 text-white transition hover:scale-[1.02]"
                      >
                        <Video className="h-7 w-7" />
                      </button>
                    )
                  ) : (
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="inline-flex h-16 items-center justify-center gap-2 rounded-full border border-white bg-[linear-gradient(90deg,#ffffff_0%,#f3f3ff_100%)] px-6 text-sm font-semibold text-black transition hover:opacity-90"
                    >
                      <Upload className="h-4 w-4" />
                      Upload
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() =>
                      setSource((current) => (current === 'camera' ? 'upload' : 'camera'))
                    }
                    className="inline-flex h-12 w-12 items-center justify-center rounded-full border border-white/10 bg-black/60 text-white transition hover:bg-black/75"
                  >
                    {source === 'camera' ? (
                      <Upload className="h-5 w-5" />
                    ) : (
                      <Camera className="h-5 w-5" />
                    )}
                  </button>
                </div>
              ) : (
                <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-3 bg-gradient-to-t from-black/90 via-black/20 to-transparent px-4 pb-4 pt-20">
                  <button
                    type="button"
                    onClick={clearCapture}
                    className="inline-flex h-12 w-12 items-center justify-center rounded-full border border-white/10 bg-black/60 text-white transition hover:bg-black/75"
                  >
                    <RotateCcw className="h-5 w-5" />
                  </button>

                  <button
                    type="button"
                    onClick={handlePublish}
                    disabled={publishing}
                    className="inline-flex h-14 items-center justify-center gap-2 rounded-full border border-white bg-[linear-gradient(90deg,#ffffff_0%,#f3f3ff_100%)] px-6 text-sm font-semibold text-black transition hover:opacity-90 disabled:opacity-70"
                  >
                    {publishing ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Check className="h-4 w-4" />
                    )}
                    Publish
                  </button>

                  <button
                    type="button"
                    onClick={clearCapture}
                    className="inline-flex h-12 w-12 items-center justify-center rounded-full border border-white/10 bg-black/60 text-white transition hover:bg-black/75"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
              )}
            </div>
          </section>

          <aside className="space-y-5">
            <section className="rounded-[26px] md:rounded-[28px] border border-zinc-800/90 bg-[linear-gradient(180deg,rgba(18,18,24,0.98),rgba(8,8,10,0.98))] p-5 shadow-[0_14px_32px_rgba(0,0,0,0.20)]">
              <div className="inline-flex rounded-full border border-violet-500/20 bg-violet-500/10 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.16em] text-violet-200">
                Source
              </div>

              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={() => {
                    setSource('camera')
                    clearCapture()
                  }}
                  className={`rounded-[20px] border px-4 py-4 text-left text-sm transition ${
                    source === 'camera'
                      ? 'border-white bg-white text-black'
                      : 'border-zinc-800 bg-zinc-950/90 text-zinc-300 hover:border-zinc-700 hover:text-white'
                  }`}
                >
                  In-app camera
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setSource('upload')
                    clearCapture()
                  }}
                  className={`rounded-[20px] border px-4 py-4 text-left text-sm transition ${
                    source === 'upload'
                      ? 'border-white bg-white text-black'
                      : 'border-zinc-800 bg-zinc-950/90 text-zinc-300 hover:border-zinc-700 hover:text-white'
                  }`}
                >
                  Upload device media
                </button>
              </div>
            </section>

            <section className="rounded-[26px] md:rounded-[28px] border border-zinc-800/90 bg-[linear-gradient(180deg,rgba(18,18,24,0.98),rgba(8,8,10,0.98))] p-5 shadow-[0_14px_32px_rgba(0,0,0,0.20)]">
              <div className="inline-flex rounded-full border border-violet-500/20 bg-violet-500/10 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.16em] text-violet-200">
                Capture mode
              </div>

              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={() => {
                    setMode('photo')
                    clearCapture()
                  }}
                  className={`rounded-[20px] border px-4 py-4 text-left text-sm transition ${
                    mode === 'photo'
                      ? 'border-white bg-white text-black'
                      : 'border-zinc-800 bg-zinc-950/90 text-zinc-300 hover:border-zinc-700 hover:text-white'
                  }`}
                >
                  Photo
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setMode('video')
                    clearCapture()
                  }}
                  className={`rounded-[20px] border px-4 py-4 text-left text-sm transition ${
                    mode === 'video'
                      ? 'border-white bg-white text-black'
                      : 'border-zinc-800 bg-zinc-950/90 text-zinc-300 hover:border-zinc-700 hover:text-white'
                  }`}
                >
                  Video
                </button>
              </div>
            </section>

            <section className="rounded-[26px] md:rounded-[28px] border border-zinc-800/90 bg-[linear-gradient(180deg,rgba(18,18,24,0.98),rgba(8,8,10,0.98))] p-5 shadow-[0_14px_32px_rgba(0,0,0,0.20)]">
              <div className="inline-flex rounded-full border border-cyan-500/20 bg-cyan-500/10 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.16em] text-cyan-200">
                Destination
              </div>

              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={() => setTarget('post')}
                  className={`rounded-[20px] border px-4 py-4 text-left text-sm transition ${
                    target === 'post'
                      ? 'border-white bg-white text-black'
                      : 'border-zinc-800 bg-zinc-950/90 text-zinc-300 hover:border-zinc-700 hover:text-white'
                  }`}
                >
                  Publish as post
                </button>

                <button
                  type="button"
                  onClick={() => setTarget('story')}
                  className={`rounded-[20px] border px-4 py-4 text-left text-sm transition ${
                    target === 'story'
                      ? 'border-white bg-white text-black'
                      : 'border-zinc-800 bg-zinc-950/90 text-zinc-300 hover:border-zinc-700 hover:text-white'
                  }`}
                >
                  Publish as story
                </button>
              </div>

              <div className="mt-5 space-y-3">
                <label className="block text-sm font-medium text-zinc-300">
                  Caption
                </label>
                <textarea
                  value={caption}
                  onChange={(event) => setCaption(event.target.value)}
                  rows={4}
                  maxLength={280}
                  placeholder="Write a caption..."
                  className="min-h-[110px] w-full rounded-[20px] border border-zinc-700 bg-zinc-950 px-4 py-3 text-sm leading-7 text-white outline-none placeholder:text-zinc-500"
                />
              </div>

              {target === 'post' ? (
                <div className="mt-5 space-y-3">
                  <label className="block text-sm font-medium text-zinc-300">
                    Category
                  </label>
                  <select
                    value={categoryId}
                    onChange={(event) => setCategoryId(event.target.value)}
                    className="w-full rounded-[20px] border border-zinc-700 bg-zinc-950 px-4 py-3 text-sm text-white outline-none"
                  >
                    <option value="">No category</option>
                    {categories.map((category) => (
                      <option key={category.id} value={category.id}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                </div>
              ) : null}
            </section>

            <section className="rounded-[26px] md:rounded-[28px] border border-zinc-800/90 bg-[linear-gradient(180deg,rgba(18,18,24,0.98),rgba(8,8,10,0.98))] p-5 shadow-[0_14px_32px_rgba(0,0,0,0.20)]">
              <div className="inline-flex rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.16em] text-zinc-300">
                Better flow
              </div>

              <ul className="mt-4 space-y-3 text-sm leading-7 text-zinc-400">
                <li>Use camera for live capture and upload when permissions fail or you already have media.</li>
                <li>Swipe right from the left edge on feed or create to open camera on mobile.</li>
                <li>Post keeps content in the main feed. Story keeps it temporary for 6 hours.</li>
              </ul>
            </section>
          </aside>
        </div>
      </div>
    </main>
  )
}